#include <stdio.h>
#include <string.h>

void encrypt(char inp[], char out[], int k) {
    for(int i=0;i<strlen(inp);i++) {
        out[i] = 'A' + (inp[i] -'A' + k)%26;
    }
}

void decrypt(char inp[], char out[], int k) {
    for(int i=0;i<strlen(inp);i++) {
        out[i] = 'A' + (inp[i] -'A' - k + 26)%26;
    }
}

int main() {
    char pt[50]={0}; //plain text
    int k; // key
    printf("Enter the plain text (in capitals): ");
    scanf("%s", pt);
    printf("Enter the key : ");
    scanf("%d", &k);

    char ct[50] = {0}; // cipher text
    char dt[50] = {0}; // decrypted text

    encrypt(pt, ct, k);
    printf("Encrypted text : %s\n", ct);

    decrypt(ct, dt, k);
    printf("Decrypted text : %s\n", dt);
    return 0;
}