#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void encrypt(char inp[], char out[], char k[]) {
    for(int i=0, j=0;i<strlen(inp);i++) {
        out[i] = 'A' + (inp[i]-'A' + k[j]-'A')%26;
        j = (j+1)%strlen(k);
    }
}

void decrypt(char inp[], char out[], char k[]) {
    for(int i=0, j=0;i<strlen(inp);i++) {
        out[i] = 'A' + (inp[i]-'A' - (k[j]-'A') + 26)%26;
        j = (j+1)%strlen(k);
    }
}

int main() {
    srand(time(NULL));
    char pt[50]={0}; //plain text
    printf("Enter the plain text (in capitals): ");
    scanf("%s", pt);

    char key[50] = {0};
    printf("Enter the key (in capitals): ");
    scanf("%s", key);

    char ct[50] = {0}; // cipher text
    char dt[50] = {0}; // decrypted text

    encrypt(pt, ct, key);
    printf("Encrypted text : %s\n", ct);

    decrypt(ct, dt, key);
    printf("Decrypted text : %s\n", dt);
    return 0;
}