#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

void genAlphabetPermutation(char map[26]) {
    for(int i=0;i<26;i++) map[i] = 'A' + i;
    for(int i=25;i>=0;i--) {
        int j = rand()%(i+1);

        char temp = map[j];
        map[j] = map[i];
        map[i] = temp;
    }
}

void encrypt(char inp[], char out[], char k[]) {
    for(int i=0;i<strlen(inp);i++) {
        out[i] = k[inp[i]-'A'];
    }
}

void decrypt(char inp[], char out[], char k[]) {
    for(int i=0;i<strlen(inp);i++) {
        for(int j=0;j<26;j++) {
            if(inp[i] == k[j]) {
                out[i] = 'A' + j;
                break;
            }
        }
    }
}

int main() {
    srand(time(NULL));
    char pt[50]={0}; //plain text
    printf("Enter the plain text (in capitals): ");
    scanf("%s", pt);

    char key[26] = {0};
    genAlphabetPermutation(key);
    printf("Generated random permutation as key : %s\n", key);

    char ct[50] = {0}; // cipher text
    char dt[50] = {0}; // decrypted text

    encrypt(pt, ct, key);
    printf("Encrypted text : %s\n", ct);

    decrypt(ct, dt, key);
    printf("Decrypted text : %s\n", dt);
    return 0;
}