#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>


void genPlayFairMatrix(char mat[5][5],char key[]) {
    bool taken[26]={0};
    taken['J'-'A'] = 1;

    int i=0, j=0;
    for(int k=0;k<strlen(key);k++) {
        if(!taken[key[k]-'A']) {
            mat[i][j] = key[k];
            j = (j+1)%5;
            i+=(j==0);
            taken[key[k]-'A'] = 1;
        }
    }
    for(int k=0;k<26;k++) {
        if(!taken[k]) {
            mat[i][j] = 'A' + k;
            j = (j+1)%5;
            i+=(j==0);
            taken[k] = 1;
        }
    }
}
void printPlayFair(char mat[][5]) {
    for(int i=0;i<5;i++) {
        for(int j=0;j<5;j++) {
            printf("%c ", mat[i][j]);
        }
        printf("\n");
    }
}
void removeSpaces(char str[]) {
    int i, count = 0;
	for (i = 0; i < strlen(str); i++)
		if (str[i] != ' ')
			str[count++] = str[i];
	str[count] = '\0';
}

void search(char keyT[5][5], char a, char b, int arr[])
{
	int i, j;

	if (a == 'j')
		a = 'i';
	else if (b == 'j')
		b = 'i';

	for (i = 0; i < 5; i++) {

		for (j = 0; j < 5; j++) {

			if (keyT[i][j] == a) {
				arr[0] = i;
				arr[1] = j;
			}
			else if (keyT[i][j] == b) {
				arr[2] = i;
				arr[3] = j;
			}
		}
	}
}

int mod5(int a) { return (a % 5); }

void encrypt(char str[], char keyT[5][5], int ps, char cipher[])
{
	int i, a[4];
	int idx = 0;

	for (i = 0; i < ps; ) {
		
		if ((i+1) == ps) {
			search (keyT, str[i], 'Z', a);
			++i;
		} else if (str[i] == str[i+1]) {
			search (keyT, str[i], 'X', a);
			++i;
		} else {
			search(keyT, str[i], str[i + 1], a);
			i += 2;
		}

		if (a[0] == a[2]) {
			cipher[idx] = keyT[a[0]][mod5(a[1] + 1)];
			cipher[idx + 1] = keyT[a[0]][mod5(a[3] + 1)];
		}
		else if (a[1] == a[3]) {
			cipher[idx] = keyT[mod5(a[0] + 1)][a[1]];
			cipher[idx + 1] = keyT[mod5(a[2] + 1)][a[1]];
		}
		else {
			cipher[idx] = keyT[a[0]][a[3]];
			cipher[idx + 1] = keyT[a[2]][a[1]];
		}
		idx += 2;
	}
	cipher[idx] = '\0';
}

int main() {
    srand(time(NULL));
    char pt[50]={0}; //plain text
    printf("Enter the plain text (in capitals): ");
    fgets(pt, 50, stdin);
    pt[strcspn(pt, "\n")] = 0;

    char key[50] = {0};
    printf("Enter the key (in capitals): ");
    fgets(key, 50, stdin);
    key[strcspn(key, "\n")] = 0;

    removeSpaces(pt);
    removeSpaces(key);

    printf("'%s' '%s'\n", pt , key);
    char mat[5][5];
    genPlayFairMatrix(mat, key);
    printPlayFair(mat);

    char ct[50] = {0}; // cipher text
    // encrypt(pt, ct, mat);
    encrypt(pt, mat, strlen(pt), ct);
    printf("Encrypted text : %s\n", ct);

    return 0;
}