/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <gmp.h>
#include <time.h>

void Init(mpz_t p, mpz_t q)
{
    mpz_t c, randd;
    mpz_inits(p, q, c, randd, NULL);

    gmp_randstate_t state;

    gmp_randinit_mt(state);

    unsigned long seed;
    seed = time(NULL);
    gmp_randseed_ui(state, seed);

    int bits = 1024;

    mpz_rrandomb(randd, state, bits);
    mpz_nextprime(p, randd);

    mpz_add_ui(c, p, 1);

    mpz_nextprime(q, c);

    gmp_printf("P : %Zd\n\n q : %Zd \n\n", p, q);
}
void PublicKey(mpz_t fhi, mpz_t pubKey)
{
    mpz_t randd, t;

    mpz_inits(randd, pubKey, t, NULL);
    while (1)
    {
        gmp_randstate_t state;

        gmp_randinit_mt(state);

        unsigned long seed;
        seed = time(NULL);
        gmp_randseed_ui(state, seed);

        int bits = 1024;

        mpz_rrandomb(randd, state, bits);
        //	gmp_printf("%Zd\n", randd);
        mpz_gcd(t, fhi, randd);
        if (mpz_cmp_ui(t, 1) == 0)
            break;
    }
    mpz_set(pubKey, randd);
    gmp_printf("PUBLIC KEY : %Zd\n\n", randd);
}

void Encrypt(mpz_t enc, mpz_t base, mpz_t expo, mpz_t mod)
{
    mpz_powm(enc, base, expo, mod);
}

int main()
{

    mpz_t p, q, n, q1, p1, fhi, PubKey, PriKey, enc, base, dec;
    Init(p, q);

    mpz_inits(n, fhi, PubKey, PriKey, q1, p1, enc, base, dec, NULL);

    mpz_mul(n, p, q);

    mpz_sub_ui(q1, q, 1);
    //   gmp_printf("%Zd\n",q1);
    mpz_sub_ui(p1, p, 1);
    //    gmp_printf("%Zd\n",p1);
    mpz_mul(fhi, p1, q1);

    PublicKey(fhi, PubKey);

    mpz_invert(PriKey, PubKey, fhi);

    gmp_printf("Private Key ::    %Zd\n\n", PriKey);
    mpz_set_ui(base, 123456789);
    gmp_printf("Text to be Encrypted: %Zd \n\n", base);
    Encrypt(enc, base, PubKey, n);

    gmp_printf("Encryption : %Zd \n\n", enc);

    Encrypt(dec, enc, PriKey, n);

    gmp_printf("Decryption : %Zd \n\n", dec);

    return 0;
}
