#include<bits/stdc++.h>
using namespace std;
map<char,char>mp;
char inverse_map(char ch,map<char,char>mp)
{
	for(int i=0;i<26;i++)
	{
		if(mp['a'+i]==ch)
			return (char)('a'+i);
	}
	
}
void encrypt(string &str)
{
	for(int i=0;i<str.length();i++)
	str[i]=mp[str[i]];
}
void decrypt(string &str)
{
	for(int i=0;i<str.length();i++)
	str[i]=inverse_map(str[i],mp);
}

void permutate(vector<char>v)
{
	int n,val;
	for(int i=0;i<26;i++)
	{
		n=v.size();
		val=rand()%n;
		mp['a'+i]=v[val];
		v.erase(v.begin()+val);
	}
}
int main()
{
int n;
vector<char>v;
for(int i=0;i<26;i++)
v.push_back('a'+i);
string str,encrypted_str;
printf("Enter the text : \n");
cin>>str;
n=str.length();
permutate(v);
cout<<"*******************"<<endl;
printf("On Encryption our text is : \n");
encrypt(str);
cout<<str<<endl;
printf("On Decryption our text is : \n");
decrypt(str);
cout<<str<<endl;
return 0;
}


