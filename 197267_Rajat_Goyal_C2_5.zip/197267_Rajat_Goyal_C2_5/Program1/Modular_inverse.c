#include<gmp.h>
#include<stdio.h>
void func(mpz_t gcd,mpz_t a,mpz_t b,mpz_t x,mpz_t y)
{
	if(mpz_cmp_ui(a,0)==0)
	{
		mpz_set_ui(x,0);
		mpz_set_ui(y,1);
		mpz_set(gcd,b);
		return;
	}
	mpz_t x1,y1,rop,temp;
	mpz_inits(x1,y1,rop,temp,NULL);
	mpz_mod(rop,b,a);  //rop=b%a
	func(gcd,rop,a,x1,y1);
	mpz_fdiv_q(temp,b,a);
	mpz_mul(temp,temp,x1);
	mpz_sub(temp,y1,temp);
	mpz_set(x,temp);
	mpz_set(y,x1);
}
void main()
{
mpz_t a,b,gcd,x,y;
mpz_inits(a,b,gcd,x,y,NULL);
gmp_printf("\n enter value of the number : ");
gmp_scanf("%Zd",a);
gmp_printf("\n enter value of the modulo : ");
gmp_scanf("%Zd",b);
mpz_gcd(gcd,a,b);
if(mpz_cmp_ui(gcd,1)!=0)
gmp_printf("\n modular inverse of %Zd over modulo %Zd doesnot exist \n",a,b);
func(gcd,a,b,x,y);
mpz_add(x,x,b);
mpz_mod (x, x, b);
gmp_printf("\n The inverse of %Zd over modulo %Zd is : %Zd \n",a,b,x);
return;
}


